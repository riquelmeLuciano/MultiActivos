import { useState } from "react";

type Tab = "plazos" | "fci";

interface PlazoFijo {
  entidad: string;
  tna: number;
  vencimiento: string;
  capital: number;
  interesEstimado: number;
  diasRestantes: number;
}

interface FondoComun {
  fondo: string;
  rendDiario: number;
  tnaAnualizada: number;
  liquidez: "24hs" | "48hs" | "72hs" | "Inmediata";
  capitalColocado: number;
}

const plazosData: PlazoFijo[] = [
  { entidad: "Banco Galicia", tna: 118.0, vencimiento: "12/09/2026", capital: 500000, interesEstimado: 16246, diasRestantes: 16 },
  { entidad: "Banco Nación", tna: 114.5, vencimiento: "19/09/2026", capital: 1200000, interesEstimado: 47047, diasRestantes: 23 },
  { entidad: "BBVA Argentina", tna: 119.5, vencimiento: "05/10/2026", capital: 750000, interesEstimado: 64151, diasRestantes: 39 },
  { entidad: "Santander", tna: 116.0, vencimiento: "27/09/2026", capital: 300000, interesEstimado: 13315, diasRestantes: 31 },
  { entidad: "Banco Macro", tna: 121.0, vencimiento: "15/10/2026", capital: 2000000, interesEstimado: 199561, diasRestantes: 49 },
  { entidad: "ICBC", tna: 117.0, vencimiento: "02/09/2026", capital: 450000, interesEstimado: 7763, diasRestantes: 6 },
  { entidad: "Brubank", tna: 122.5, vencimiento: "26/10/2026", capital: 180000, interesEstimado: 21900, diasRestantes: 60 },
];

const fciData: FondoComun[] = [
  { fondo: "Fima Premium (Galicia)", rendDiario: 0.312, tnaAnualizada: 113.88, liquidez: "Inmediata", capitalColocado: 880000 },
  { fondo: "Consultatio T+1", rendDiario: 0.318, tnaAnualizada: 116.07, liquidez: "24hs", capitalColocado: 1500000 },
  { fondo: "Balanz Capital Money Market", rendDiario: 0.309, tnaAnualizada: 112.79, liquidez: "Inmediata", capitalColocado: 620000 },
  { fondo: "MAF Ahorro Pesos", rendDiario: 0.321, tnaAnualizada: 117.17, liquidez: "24hs", capitalColocado: 2100000 },
  { fondo: "SBS Ahorro Pesos", rendDiario: 0.305, tnaAnualizada: 111.33, liquidez: "48hs", capitalColocado: 340000 },
  { fondo: "Allaria Ahorro", rendDiario: 0.315, tnaAnualizada: 114.97, liquidez: "Inmediata", capitalColocado: 760000 },
  { fondo: "Criteria Ahorro Plus", rendDiario: 0.298, tnaAnualizada: 108.77, liquidez: "72hs", capitalColocado: 450000 },
];

const fmt = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(n);

const totalCapital =
  plazosData.reduce((a, b) => a + b.capital, 0) +
  fciData.reduce((a, b) => a + b.capitalColocado, 0);

/* ── theme tokens ─────────────────────────────────────────────── */
const T = {
  light: {
    bg: "#FAFAFA",
    surface: "#ffffff",
    border: "#e5e7eb",
    rowDivider: "#f3f4f6",
    rowHover: "#f9fafb",
    theadBg: "#fafafa",
    text: "#111827",
    textMuted: "#9ca3af",
    textSecondary: "#374151",
    tabBg: "#f1f1f1",
    tabActive: "#ffffff",
    tabActiveText: "#0f0f0f",
    tabInactiveText: "#6b7280",
    kpiText: "#0f0f0f",
    toggleBg: "#f3f4f6",
    toggleBorder: "#e5e7eb",
    toggleIcon: "#6b7280",
    toggleHover: "#e5e7eb",
    fabBg: "#0f0f0f",
    fabIcon: "#ffffff",
    fabHover: "#262626",
    fabShadow: "0 4px 20px rgba(0,0,0,0.18)",
  },
  dark: {
    bg: "#0d0d0d",
    surface: "#161616",
    border: "#2a2a2a",
    rowDivider: "#1e1e1e",
    rowHover: "#1c1c1c",
    theadBg: "#111111",
    text: "#f3f4f6",
    textMuted: "#6b7280",
    textSecondary: "#9ca3af",
    tabBg: "#1e1e1e",
    tabActive: "#2a2a2a",
    tabActiveText: "#f3f4f6",
    tabInactiveText: "#6b7280",
    kpiText: "#f3f4f6",
    toggleBg: "#1e1e1e",
    toggleBorder: "#2a2a2a",
    toggleIcon: "#9ca3af",
    toggleHover: "#2a2a2a",
    fabBg: "#f3f4f6",
    fabIcon: "#0d0d0d",
    fabHover: "#e5e7eb",
    fabShadow: "0 4px 20px rgba(0,0,0,0.5)",
  },
} as const;

type Theme = typeof T.light;

const liquidezClasses: Record<string, { bg: string; text: string; border: string }> = {
  Inmediata: { bg: "#f0fdf4", text: "#065f46", border: "#a7f3d0" },
  "24hs": { bg: "#eff6ff", text: "#1d4ed8", border: "#bfdbfe" },
  "48hs": { bg: "#fffbeb", text: "#92400e", border: "#fde68a" },
  "72hs": { bg: "#fff1f2", text: "#be123c", border: "#fecdd3" },
};

const liquidezClassesDark: Record<string, { bg: string; text: string; border: string }> = {
  Inmediata: { bg: "#052e16", text: "#6ee7b7", border: "#065f46" },
  "24hs": { bg: "#1e3a5f", text: "#93c5fd", border: "#1d4ed8" },
  "48hs": { bg: "#2d1b00", text: "#fcd34d", border: "#92400e" },
  "72hs": { bg: "#3b0a1c", text: "#fda4af", border: "#be123c" },
};

/* ── Sun icon ─────────────────────────────────────────────────── */
function SunIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="5" />
      <line x1="12" y1="1" x2="12" y2="3" />
      <line x1="12" y1="21" x2="12" y2="23" />
      <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
      <line x1="1" y1="12" x2="3" y2="12" />
      <line x1="21" y1="12" x2="23" y2="12" />
      <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
      <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
    </svg>
  );
}

/* ── Moon icon ────────────────────────────────────────────────── */
function MoonIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  );
}

/* ── Sparkle / assistant icon ─────────────────────────────────── */
function SparkleIcon({ color }: { color: string }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z" />
    </svg>
  );
}

/* ── Main App ─────────────────────────────────────────────────── */
export default function App() {
  const [tab, setTab] = useState<Tab>("plazos");
  const [dark, setDark] = useState(false);
  const [fabHovered, setFabHovered] = useState(false);
  const [toggleHovered, setToggleHovered] = useState(false);

  const th: Theme = dark ? T.dark : T.light;

  const now = new Date();
  const timestamp =
    now.toLocaleDateString("es-AR", { day: "2-digit", month: "long", year: "numeric" }) +
    " · " +
    now.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" });

  return (
    <div
      style={{
        minHeight: "100%",
        width: "100%",
        backgroundColor: th.bg,
        fontFamily: "'Inter', system-ui, sans-serif",
        color: th.text,
        transition: "background-color 0.25s ease, color 0.25s ease",
      }}
    >
      <div style={{ maxWidth: "72rem", margin: "0 auto", padding: "2.5rem 1.5rem" }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "2rem" }}>
          <div>
            <h1 style={{ fontSize: "1.25rem", fontWeight: 600, letterSpacing: "-0.02em", color: th.kpiText, margin: 0 }}>
              Pipeline de Inversiones
            </h1>
            <p style={{ fontSize: "0.72rem", color: th.textMuted, marginTop: "3px", fontVariantNumeric: "tabular-nums" }}>
              {timestamp}
            </p>
          </div>

          {/* Right: KPI + theme toggle */}
          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            <div style={{ textAlign: "right" }}>
              <p style={{ fontSize: "0.65rem", textTransform: "uppercase", letterSpacing: "0.08em", color: th.textMuted, marginBottom: "3px" }}>
                Patrimonio Total
              </p>
              <p
                style={{
                  fontSize: "1.35rem",
                  fontWeight: 600,
                  letterSpacing: "-0.03em",
                  color: th.kpiText,
                  fontFamily: "'JetBrains Mono', monospace",
                  fontVariantNumeric: "tabular-nums",
                  transition: "color 0.25s ease",
                }}
              >
                {fmt(totalCapital)}
              </p>
            </div>

            {/* Theme toggle */}
            <button
              onClick={() => setDark((d) => !d)}
              onMouseEnter={() => setToggleHovered(true)}
              onMouseLeave={() => setToggleHovered(false)}
              title={dark ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                width: "34px",
                height: "34px",
                borderRadius: "8px",
                border: `1px solid ${th.toggleBorder}`,
                backgroundColor: toggleHovered ? th.toggleHover : th.toggleBg,
                color: th.toggleIcon,
                cursor: "pointer",
                transition: "background-color 0.15s ease, border-color 0.25s ease",
                flexShrink: 0,
              }}
            >
              {dark ? <SunIcon /> : <MoonIcon />}
            </button>
          </div>
        </div>

        {/* Tab Switcher */}
        <div
          style={{
            display: "inline-flex",
            borderRadius: "8px",
            backgroundColor: th.tabBg,
            padding: "3px",
            marginBottom: "20px",
            gap: "2px",
            transition: "background-color 0.25s ease",
          }}
        >
          {(["plazos", "fci"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                padding: "5px 14px",
                borderRadius: "6px",
                fontSize: "0.75rem",
                fontWeight: 500,
                border: "none",
                cursor: "pointer",
                transition: "all 0.15s ease",
                backgroundColor: tab === t ? th.tabActive : "transparent",
                color: tab === t ? th.tabActiveText : th.tabInactiveText,
                boxShadow: tab === t ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
              }}
            >
              {t === "plazos" ? "Plazos Fijos" : "Fondos Comunes (FCI)"}
            </button>
          ))}
        </div>

        {/* Table Card */}
        <div
          style={{
            backgroundColor: th.surface,
            border: `1px solid ${th.border}`,
            borderRadius: "10px",
            overflow: "hidden",
            transition: "background-color 0.25s ease, border-color 0.25s ease",
          }}
        >
          {tab === "plazos" ? (
            <PlazosTable data={plazosData} th={th} />
          ) : (
            <FCITable data={fciData} th={th} dark={dark} />
          )}
        </div>

        {/* Footer summary */}
        <div style={{ marginTop: "16px", display: "flex", gap: "32px", padding: "0 2px" }}>
          <Stat label="Capital en PF" value={fmt(plazosData.reduce((a, b) => a + b.capital, 0))} th={th} />
          <Stat label="Interés estimado total" value={fmt(plazosData.reduce((a, b) => a + b.interesEstimado, 0))} green th={th} />
          <Stat label="Capital en FCI" value={fmt(fciData.reduce((a, b) => a + b.capitalColocado, 0))} th={th} />
          <Stat label="Instrumentos activos" value={String(plazosData.length + fciData.length)} th={th} />
        </div>
      </div>

      {/* Floating Assistant Button */}
      <button
        onMouseEnter={() => setFabHovered(true)}
        onMouseLeave={() => setFabHovered(false)}
        title="Asistente financiero"
        style={{
          position: "fixed",
          bottom: "28px",
          right: "28px",
          width: "52px",
          height: "52px",
          borderRadius: "50%",
          border: "none",
          backgroundColor: fabHovered ? th.fabHover : th.fabBg,
          boxShadow: th.fabShadow,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          transition: "background-color 0.18s ease, transform 0.18s ease, box-shadow 0.18s ease",
          transform: fabHovered ? "scale(1.08)" : "scale(1)",
          zIndex: 50,
        }}
      >
        <SparkleIcon color={th.fabIcon} />
      </button>
    </div>
  );
}

function Stat({ label, value, green, th }: { label: string; value: string; green?: boolean; th: Theme }) {
  return (
    <div>
      <p style={{ fontSize: "0.65rem", textTransform: "uppercase", letterSpacing: "0.07em", color: th.textMuted }}>{label}</p>
      <p
        style={{
          fontSize: "0.85rem",
          fontWeight: 500,
          fontFamily: "'JetBrains Mono', monospace",
          fontVariantNumeric: "tabular-nums",
          color: green ? "#059669" : th.textSecondary,
          marginTop: "2px",
          transition: "color 0.25s ease",
        }}
      >
        {value}
      </p>
    </div>
  );
}

function PlazosTable({ data, th }: { data: PlazoFijo[]; th: Theme }) {
  return (
    <table style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr style={{ borderBottom: `1px solid ${th.border}` }}>
          {["Entidad / Banco", "TNA", "Vencimiento", "Días", "Capital", "Interés Estimado"].map((h) => (
            <Th key={h} th={th}>{h}</Th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.map((row, i) => (
          <PlazoRow key={i} row={row} last={i === data.length - 1} th={th} />
        ))}
      </tbody>
    </table>
  );
}

function PlazoRow({ row, last, th }: { row: PlazoFijo; last: boolean; th: Theme }) {
  return (
    <tr
      style={{ borderBottom: last ? "none" : `1px solid ${th.rowDivider}`, transition: "background 0.1s" }}
      onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.backgroundColor = th.rowHover)}
      onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.backgroundColor = "transparent")}
    >
      <Td th={th}>
        <span style={{ fontWeight: 500, color: th.text }}>{row.entidad}</span>
      </Td>
      <Td mono green th={th}>{row.tna.toFixed(1)}%</Td>
      <Td mono th={th}>{row.vencimiento}</Td>
      <Td th={th}>
        <span
          style={{
            display: "inline-block",
            padding: "1px 6px",
            borderRadius: "4px",
            fontSize: "0.7rem",
            fontFamily: "'JetBrains Mono', monospace",
            backgroundColor: row.diasRestantes <= 10 ? "#fff1f2" : "#f0fdf4",
            color: row.diasRestantes <= 10 ? "#e11d48" : "#065f46",
            border: `1px solid ${row.diasRestantes <= 10 ? "#fecdd3" : "#a7f3d0"}`,
          }}
        >
          {row.diasRestantes}d
        </span>
      </Td>
      <Td mono th={th}>{fmt(row.capital)}</Td>
      <Td mono green th={th}>{fmt(row.interesEstimado)}</Td>
    </tr>
  );
}

function FCITable({ data, th, dark }: { data: FondoComun[]; th: Theme; dark: boolean }) {
  const liqColors = dark ? liquidezClassesDark : liquidezClasses;
  return (
    <table style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr style={{ borderBottom: `1px solid ${th.border}` }}>
          {["Fondo de Inversión", "Rend. Diario", "TNA Anualizada", "Liquidez", "Capital Colocado"].map((h) => (
            <Th key={h} th={th}>{h}</Th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.map((row, i) => (
          <FCIRow key={i} row={row} last={i === data.length - 1} th={th} liqColors={liqColors} />
        ))}
      </tbody>
    </table>
  );
}

function FCIRow({
  row, last, th, liqColors,
}: {
  row: FondoComun;
  last: boolean;
  th: Theme;
  liqColors: Record<string, { bg: string; text: string; border: string }>;
}) {
  const liq = liqColors[row.liquidez];
  return (
    <tr
      style={{ borderBottom: last ? "none" : `1px solid ${th.rowDivider}`, transition: "background 0.1s" }}
      onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.backgroundColor = th.rowHover)}
      onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.backgroundColor = "transparent")}
    >
      <Td th={th}>
        <span style={{ fontWeight: 500, color: th.text }}>{row.fondo}</span>
      </Td>
      <Td mono green th={th}>+{row.rendDiario.toFixed(3)}%</Td>
      <Td mono green th={th}>{row.tnaAnualizada.toFixed(2)}%</Td>
      <Td th={th}>
        <span
          style={{
            fontSize: "0.68rem",
            fontWeight: 500,
            padding: "2px 7px",
            borderRadius: "4px",
            border: `1px solid ${liq.border}`,
            display: "inline-block",
            backgroundColor: liq.bg,
            color: liq.text,
          }}
        >
          {row.liquidez}
        </span>
      </Td>
      <Td mono th={th}>{fmt(row.capitalColocado)}</Td>
    </tr>
  );
}

function Th({ children, th }: { children: React.ReactNode; th: Theme }) {
  return (
    <th
      style={{
        padding: "10px 16px",
        textAlign: "left",
        fontSize: "0.65rem",
        fontWeight: 600,
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        color: th.textMuted,
        whiteSpace: "nowrap",
        backgroundColor: th.theadBg,
        transition: "background-color 0.25s ease, color 0.25s ease",
      }}
    >
      {children}
    </th>
  );
}

function Td({ children, mono, green, th }: { children: React.ReactNode; mono?: boolean; green?: boolean; th: Theme }) {
  return (
    <td
      style={{
        padding: "11px 16px",
        fontSize: "0.82rem",
        fontFamily: mono ? "'JetBrains Mono', monospace" : "'Inter', sans-serif",
        fontVariantNumeric: mono ? "tabular-nums" : undefined,
        color: green ? "#059669" : th.textSecondary,
        whiteSpace: "nowrap",
        transition: "color 0.25s ease",
      }}
    >
      {children}
    </td>
  );
}
